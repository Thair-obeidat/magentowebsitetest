import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MyFirstTest {
	WebDriver driver = new ChromeDriver();
	String myWebsite = "https://magento.softwaretestingboard.com/";
	Random rand = new Random();
	String password = "iLoveMyDad24@6@1947";
	String LogoutPage = "https://magento.softwaretestingboard.com/customer/account/logout/";
	String emailAddressToLogin = "";
	String passwordAddressToLogin = "";

	@BeforeTest
	public void mySetUp() {
		driver.manage().window().maximize();
		driver.get(myWebsite);
	}

	@Test
	public void CreateAnAccount() {

		WebElement CreateAccountPage = driver.findElement(By.linkText("Create an Account"));
		CreateAccountPage.click();
//		String[] thearrayNameforExampleFirstNames = { "firstname1", "firstname2", "firstname3" };
		String[] first_Names = { "Alice", "Bob", "Charlie", "David", "Eve" };
		String[] last_Names = { "Smith", "Johnson", "Williams", "Jones", "Brown" };
		String[] domainNames = { "@gmail.com", "@yahoo.com", "@outlook.com" };
		int randomIndexForTheFirstName = rand.nextInt(first_Names.length);
		int randomIndexForTheSecondName = rand.nextInt(last_Names.length);
		int randomIndexForThedomainNames = rand.nextInt(domainNames.length);
		System.out.println(randomIndexForTheFirstName);
		System.out.println(randomIndexForTheSecondName);
		WebElement FirstNameInput = driver.findElement(By.id("firstname"));
		WebElement LastNameInput = driver.findElement(By.id("lastname"));
		WebElement emailAddressInput = driver.findElement(By.id("email_address"));
		WebElement passwordInput = driver.findElement(By.id("password"));
		WebElement passwordconfirmInput = driver.findElement(By.id("password-confirmation"));
		WebElement createAccountButton = driver.findElement(By.xpath("//button[@title='Create an Account']"));

		String firstname = first_Names[randomIndexForTheFirstName];
		String lastname = last_Names[randomIndexForTheSecondName];
		int randomnumber = rand.nextInt(9841);
		String domainname = domainNames[randomIndexForThedomainNames];

		FirstNameInput.sendKeys(firstname);
		LastNameInput.sendKeys(lastname);
		emailAddressInput.sendKeys(firstname + lastname + randomnumber + domainname);
		passwordInput.sendKeys(password);
		passwordconfirmInput.sendKeys((password));
		createAccountButton.click();

		emailAddressToLogin = firstname + lastname + randomnumber + domainname;
		passwordAddressToLogin = password;

	}

	@Test(priority = 2)
	public void Logout() {
		driver.get(LogoutPage);
	}

	@Test(priority = 3)
	public void login() {
		WebElement LoginPage = driver.findElement(By.linkText("Sign In"));
		WebElement emaillogin = driver.findElement(By.id("email"));
		WebElement passwordlogin = driver.findElement(By.id("pass"));
		WebElement buttonLogin = driver.findElement(By.id("send2"));


		LoginPage.click();
		emaillogin.sendKeys(emailAddressToLogin);
		passwordlogin.sendKeys(passwordAddressToLogin);
		buttonLogin.click();
	}
}
